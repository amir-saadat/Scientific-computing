#include <stdio.h>
#include <stdlib.h>
#include <papi.h>
#include <string.h>

/* Initialize a matrix various values */
static void init_matrix(double* A, int rows, int columns) {
   
   int i,j;
   
   for(j = 0; j < rows; j++) {
       for (i = 0; i < columns; i++) {
	 A[(j*columns) + i] = (double)(i*j+j*2-3*i);
      }
   }
}

/* C=A*B */
static void naive_dgemm(int n,
		 double *A,
		 double *B,
		 double *C) {
   
   int i,j,k;
   double s;

   for(i=0;i<n;i++) {
      for(j=0;j<n;j++) {

         s=0.0;
         for(k=0;k<n;k++) {
	    /* cij = cij + aik + bkj */
            s+=A[(k*n)+i]*B[(j*n)+k];
         }
         C[(j*n)+i]=s;
      }
   }
}

#define DEFAULT_MATRIXSIZE 1000

int main(int argc, char** argv) {

   int n = DEFAULT_MATRIXSIZE;
   int retval;
   long long values[2];
   long long start_usecs,stop_usecs;
   int native;
   int event_set=PAPI_NULL;
   char *event_name;
   
   double *A,*B,*C;

   /* Command line argument 1 is matrix size */
   if (argc>1) {
      n=atoi(argv[1]);
   }

   /* Command line argument 2 is event name */
   if (argc>2) {
      event_name=strdup(argv[2]);
   }
   else {
     event_name=strdup("PAPI_FP_OPS");
   }

   printf("Performing a %dx%d matrix-matrix multiply, will need %ld bytes of memory\n",
	  n,n,(n*n+n*n+n*n+n*n)*sizeof(double));

   /* Allocate matrices */
   A=calloc(n*n,sizeof(double));
   B=calloc(n*n,sizeof(double));
   C=calloc(n*n,sizeof(double));
   
   if ((A==NULL) || (B==NULL) || (C==NULL)) {
      fprintf(stderr,"Error allocating memory!\n");
      exit(1);
   }
      
   /* initialize matrices */
   init_matrix(A, n, n);
   init_matrix(B, n, n);

   /* initialize PAPI */
   retval = PAPI_library_init(PAPI_VER_CURRENT);
   if (retval != PAPI_VER_CURRENT) {
      fprintf(stderr,"Error with PAPI_library_init %d\n", retval);
   }

   /* Create EventSet */
   retval = PAPI_create_eventset( &event_set );
   if (retval != PAPI_OK) {
      fprintf(stderr,"Error creating event_set %d\n", retval);
   }

   /* Convert */
   retval = PAPI_event_name_to_code( event_name, &native );
   if (retval != PAPI_OK) {
      fprintf(stderr,"Error converting %s %d\n", event_name, retval);
   }

   /* Add event */
   retval = PAPI_add_event( event_set, native );
   if (retval != PAPI_OK) {
      fprintf(stderr,"Error adding %s %d\n", event_name,retval);
   }
   
   retval = PAPI_start( event_set );
   start_usecs=PAPI_get_virt_usec();

   naive_dgemm(n, A, B, C);

   stop_usecs=PAPI_get_virt_usec();
   retval = PAPI_stop( event_set, values );

   double rate=((double)values[0]/(double)(stop_usecs-start_usecs))*1.0e6;

   printf("Average_usecs = %lld\n",stop_usecs-start_usecs);
   printf("%s = %lld\n",event_name,values[0]);
   printf("%s/s = %.3f\n",event_name,rate);

   return 0;
}

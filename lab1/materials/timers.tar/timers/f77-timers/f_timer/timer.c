/***************************************************************
   File:     timer.c

   Return:   current time in seconds as a double value.
             The precision can be as accurate as microseconds
             (10^-6 second).

   Comment:  was tested on solaris and linux.
****************************************************************/

#include <sys/time.h>

void get_cur_time(time) 
double* time;
{
  struct timeval   tv;
  struct timezone  tz;
  
  gettimeofday(&tv, &tz);
  *time = tv.tv_sec + tv.tv_usec / 1000000.0;
} 

/* 3 flavors provided so far*/
void GET_CUR_TIME(time)
double *time;
{
  get_cur_time(time);
}

void get_cur_time__(time)
double *time;
{
  get_cur_time(time);
}

void get_cur_time_(time)
double *time;
{
  get_cur_time(time);
}

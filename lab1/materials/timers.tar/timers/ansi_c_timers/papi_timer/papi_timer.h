/***************************************************************
   File:        papi_timer.h

   Description: This implementation uses the PAPI timers to
                obtain current time in seconds.

****************************************************************/

double get_cur_time();

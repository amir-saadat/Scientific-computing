#include <stdio.h>
#include <papi.h>
#include "papi_timer.h"

int main(int argc, char** argv) {
  double btime, etime;
  int i;
  double tmp = 0;
  
  if (PAPI_library_init(PAPI_VER_CURRENT) != PAPI_VER_CURRENT) 
    exit(1);

  btime = get_cur_time();
  /* Beginning of the desired block to be measured */
  for (i = 0; i < 1000; i++) tmp += 0.09;
  /* End of the desired block to be measured */
  etime = get_cur_time();  

  printf("Elapsed Time: %16.9f second\n", etime - btime);

  return 0;
}

#include <stdio.h>
#include <mpi.h>
#include "mpi_timer.h"

int main(int argc, char** argv) {
  double btime, etime;
  int i;
  double wtick;
  double tmp = 0;
  
  MPI_Init(&argc, &argv);
  wtick = MPI_Wtick();

  btime = get_cur_time();
  /* Beginning of the desired block to be measured */
  for (i = 0; i < 1000; i++) tmp += 0.09;
  /* End of the desired block to be measured */
  etime = get_cur_time();  

  printf("Elapsed Time: %f second, Clock Resolution: %e second\n", 
	 etime - btime, wtick);

  MPI_Finalize();
  return 0;
}

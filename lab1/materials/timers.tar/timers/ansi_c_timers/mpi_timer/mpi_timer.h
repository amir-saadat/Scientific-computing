/***************************************************************
   File:        mpi_timer.h

   Description: This implementation uses a portable MPI function
                to obtain the current time in seconds as a double. 

****************************************************************/

double get_cur_time();

/***************************************************************
   File:     mpi_timer.c

   Function: get_cur_time()

   Return:   current time in seconds as a double value.
             Its accuracy may be obtained by calling MPI_Wtick().
   
   Note:     must be used with an MPI program.

****************************************************************/

#include <mpi.h>

double get_cur_time() {
  return MPI_Wtime();
} 



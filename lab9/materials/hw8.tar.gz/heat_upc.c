#include <upc.h> 
#include <math.h> 
#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include <stdlib.h> 

#define min(A,B) ((A) < (B) ? (A) : (B))
#define max(A,B) ((A) > (B) ? (A) : (B))

#ifndef prtrows
#  define prtrows 11
#endif 
#ifndef prtcols
#  define prtcols 11
#endif 
 
/* for UPC distribution: */ 
int mprocs, nprocs, iproc, kproc; 
#define rank(ip,kp) ((ip)*nprocs+(kp)) 
 
int m,n,itmax; 
#define idx(i,k) ((i)*n+(k)) 
/* xphi: distributed phi arrays with shared access pointer-array */
shared [] double * shared xphi[THREADS]; /* xphi[THREADS][m*n], phi[m*n] = xphi[MYTHREAD][m*n] */ 
/* phi = local pointer to local portion of xphi */ 
double *phi; /* usage: phi[m*n] == phi[m][n], phi[idx(i,k)] = phi[i][k] */ 
double *phin; 

/* pointer to neighbor-phi arrays */ 
shared [] double *phi_neighbor_coord0_prev; 
shared [] double *phi_neighbor_coord0_next; 
shared [] double *phi_neighbor_coord1_prev; 
shared [] double *phi_neighbor_coord1_next; 

/* xphivec: scratch arrays for UPC halo exchange of non-contiguous data */
shared [] double * shared xphivec_coord1first[THREADS];  /* ...[THREADS][m-2] = phi[i=1:m-2][k=1] */
shared [] double * shared xphivec_coord1last [THREADS];  /* ...[THREADS][m-2] = phi[i=1:m-2][k=n-2] */
/* phi = local pointer to local portion of xphivec_coord1first and xphivec_coord1last*/
double *phivec_coord1first; 
double *phivec_coord1last; 
/* pointer to neighbor-xphivec arrays */ 
shared [] double *phivec_neighbor_coord1_prev; 
shared [] double *phivec_neighbor_coord1_next;
/* local scratch arrays for received halo data */ 
double *halovec_coord1first; 
double *halovec_coord1last; 
 
/* distributed array for the partial result of each thread: */
shared double mydphimax[THREADS];

void heat(); 
 
void heatpr();

void halo_exchange(); 
 
int main(int argc, char **argv)
{
  int dim1, dim2;
  if (argc < 3) 
  {
    if(MYTHREAD == 0) { 
      printf("Synopsis: heat <dim1> <dim2> [<itmax> [<mprocs>]]\n");
      printf("\n");
      printf("Examples: heat 30 30\n");
      printf("          heat 30 30 15000\n");
      printf("          heat 30 30 15000 2\n");
    } fflush(stdout); upc_barrier; 
    exit(1); 
  } 
  dim1 = atoi(argv[1]); 
  dim2 = atoi(argv[2]); 
  itmax=15000; 
  if (argc > 3) itmax = atoi(argv[3]); 
  if (argc < 3) 
  {
    printf("Synopsis: heat <dim1> <dim2> [processes_in_first_dimension]\n\nExamples: heat 30 30\n          heat 30 30 2\n");
    exit(1); 
  } 
  
  if (argc > 4)
  {   
    mprocs = atoi(argv[4]);
  } else {
    /* Factorization of THREADS:
         Goals: mprocs * nprocs = THREADS
                dim1 / dim2 ~= mprocs / nprocs
         This would imply: mprocs ~= sqrt(THREADS*dim1/dim2) */
    mprocs = sqrt((THREADS+0.0)*dim1/dim2) + 0.5 /*rounded*/;
  } 
  if (mprocs < 1) mprocs=1;
  while (mprocs > 1)
  {
    if (THREADS/mprocs*mprocs == THREADS) break;
    mprocs--;
  } 
  nprocs = THREADS/mprocs;
 
  /* Process ranks: */ 
  iproc = MYTHREAD/nprocs;  
  kproc = MYTHREAD%nprocs;  
 
  dim1 = (dim1-1)/mprocs + 1; /*rounded up*/ 
  dim2 = (dim2-1)/nprocs + 1; /*rounded up*/ 
 
  m=dim1+2; n=dim2+2; /* two additional elements for the boundary conditions */ 
 if(MYTHREAD == 0) { 
  printf("main:   dim1  =%4d,   dim2  =%4d\n", dim1, dim2);
  printf("main: m=dim1+2=%4d, n=dim2+2=%4d\n", m, n);
  printf("main:    mprocs=%4d,    nprocs=%4d,  THREADS=%d \n", mprocs, nprocs, THREADS);
 } fflush(stdout); upc_barrier; 
  /* printf("main: MYTHREAD=%4d,   iproc=%4d,   kproc=%4d\n", MYTHREAD, iproc, kproc); */
  /* phi =(double *)malloc(m*n*sizeof(double)); */
  xphi[MYTHREAD] = (shared [] double *) upc_alloc(n*m*sizeof(double)); 
  upc_barrier; 
  phi = (double *) xphi[MYTHREAD]; 
  if (phi == (double *)0) {
    printf("ERROR on thread %d: phi is NUL pointer\n",MYTHREAD); fflush(stdout);
    exit(1);
  } 
  phin=(double *)malloc(m*n*sizeof(double)); 
  /* preparation of UPC halo exchange: */
    if (iproc>0) phi_neighbor_coord0_prev = xphi[rank(iproc-1,kproc)]; 
    if (iproc<mprocs-1) phi_neighbor_coord0_next = xphi[rank(iproc+1,kproc)]; 
    if (kproc>0) phi_neighbor_coord1_prev = xphi[rank(iproc,kproc-1)]; 
    if (kproc<nprocs-1) phi_neighbor_coord1_next = xphi[rank(iproc,kproc+1)]; 
  /* scratch arrays for UPC halo exchange of non-contiguous data */
    xphivec_coord1first[MYTHREAD] = (shared [] double *) upc_alloc((m-2)*sizeof(double)); 
    xphivec_coord1last[MYTHREAD]  = (shared [] double *) upc_alloc((m-2)*sizeof(double)); 
    upc_barrier; 
    phivec_coord1first = (double *) xphivec_coord1first[MYTHREAD]; 
    phivec_coord1last  = (double *) xphivec_coord1last[MYTHREAD]; 
    if (kproc>0) phivec_neighbor_coord1_prev = xphivec_coord1last[rank(iproc,kproc-1)]; 
    if (kproc<nprocs-1) phivec_neighbor_coord1_next = xphivec_coord1first[rank(iproc,kproc+1)]; 
    halovec_coord1first = (double *) malloc((m-2)*sizeof(double)); 
    halovec_coord1last  = (double *) malloc((m-2)*sizeof(double)); 
  heat();
  exit(0); 
}

void heat()
{
  double eps = 1.0e-08;
  double dx,dy,dx2,dy2,dx2i,dy2i,dt,dphi,dphimax;
  int i,k,it;

  clock_t t1,t2;
  struct timeval tv1,tv2; struct timezone tz;

 /* 
  dx=1.0/(n-1);
  dy=1.0/(m-1);
 */ 
  dx=1.0/((n-2)*nprocs+1);
  dy=1.0/((m-2)*mprocs+1);
  dx2=dx*dx;
  dy2=dy*dy;
  dx2i=1.0/dx2;
  dy2i=1.0/dy2;
  dt=min(dx2,dy2)/4.0;
/* start values - total area: 0.d0 */
  for (i=0;i<m;i++)
  {
    for (k=0;k<n;k++)
    {
      phi[idx(i,k)]=0.0;
    }
  }
/* start values - boundary: 1.d0 */
 if (kproc == nprocs-1) /* UPC-distributed: only if highest kproc: */
  for (i=0;i<m;i++)
  {
    phi[idx(i,n-1)]=1.0;
  }
/* start values - boundary: 0.d0 */
 if (kproc == 0) /* UPC-distributed: only if lowest kproc: */
  for (i=0;i<m;i++)
  {
    phi[idx(i,0)]=0.0;
  }
/* start values - boundary: continuously from 0 to 1 */
 if (iproc == 0) /* UPC-distributed: only if lowest iproc: */
  for (k=1;k<n-1;k++)
  {
    phi[idx(0,k)]=(k+kproc*(n-2))*dx;
  }
 if (iproc == mprocs-1) /* UPC-distributed: only if highest iproc: */
  for (k=1;k<n-1;k++)
  {
    phi[idx(m-1,k)]=(k+kproc*(n-2))*dx;
  }

 if(MYTHREAD == 0) { 
  printf("\nHeat Conduction 2d\n");
  printf("\ndx = %12.4g, dy = %12.4g, dt = %12.4g, eps = %12.4g\n",
         dx,dy,dt,eps);
  printf("\nstart values\n");
 } fflush(stdout); upc_barrier; 
  heatpr();

  gettimeofday(&tv1, &tz);
  t1=clock();

/* iteration */
  for (it=1;it<=itmax;it++)
  {
    halo_exchange(); 
    dphimax=0.;
    for (i=1;i<m-1;i++)
    {
      for (k=1;k<n-1;k++)
      {
        dphi=(phi[idx(i+1,k)]+phi[idx(i-1,k)]-2.*phi[idx(i,k)])*dy2i
            +(phi[idx(i,k+1)]+phi[idx(i,k-1)]-2.*phi[idx(i,k)])*dx2i;
        dphi=dphi*dt;
        dphimax=max(dphimax,dphi);
        phin[idx(i,k)]=phi[idx(i,k)]+dphi;
      }
    }
/* save values */
    for (i=1;i<m-1;i++)
    {
      for (k=1;k<n-1;k++)
      {
        phi[idx(i,k)]=phin[idx(i,k)];
      }
    }
 
    /* collective maximum-reduction of dphimax values: */ 
    upc_barrier; /* to guarantee that mydphimax[0] is read on all threads in previous "it" loop iteration */
    mydphimax[MYTHREAD]=dphimax;
    upc_barrier; /* to guarantee that all mydphimax[] arre stored and now readable for thread 0 */
    if (MYTHREAD==0)
    { int rank;
      dphimax=0.0;
          for (rank=0; rank<THREADS; rank++) 
          { 
            dphimax = max(dphimax, mydphimax[rank]);
      }
      mydphimax[0] = dphimax; 
    }
    upc_barrier; /* to guarantee that mydphimax[0] is updated and readable for all threads */
    dphimax = mydphimax[0]; 
 
    if(dphimax<eps) break;
  }
  if(dphimax>=eps) it=it-1;

  t2=clock();
  gettimeofday(&tv2, &tz);

 if(MYTHREAD == 0) { 
  printf("\nphi after %d iterations, dphimax=%9.3e, eps=%9.3e\n",it, dphimax, eps);
 } fflush(stdout); upc_barrier; 
  heatpr();
 if(MYTHREAD == 0) { 
  printf( "CPU time (clock)                = %12.6f sec\n", (t2-t1)/1000000.0 );
  printf( "wall clock time (gettimeofday)  = %12.6f sec\n", (tv2.tv_sec-tv1.tv_sec) + (tv2.tv_usec-tv1.tv_usec)*1e-6 );
 } fflush(stdout); upc_barrier; 
}
 
/*--------------------------------------------------------------------------*/ 

void heatpr_each_process()
{
  int i,k, prt_i,prt_k, prt_i_max, prt_k_max;

  int ip, kp;

 for(ip=0;ip<mprocs;ip++)
 { 
  for(kp=0;kp<nprocs;kp++)
  {
   if ((ip==iproc) && (kp==kproc))
   {  
    printf("Output of the proces with: iproc=%3d,  kproc=%3d\n", iproc, kproc); 
     
    prt_i_max = min(prtrows, m); 
    prt_k_max = min(prtcols, n); 
    printf("i  \\  k="); 
    for (prt_k=0; prt_k<prt_k_max; prt_k++)
    { k=1.0*prt_k/(prt_k_max-1)*(n-1) + 0.5/*rounding*/;
      printf("  %6i",k); 
    } 
    printf("\n"); 
    printf("-------+"); 
    for (prt_k=0; prt_k<prt_k_max; prt_k++)
    { k=1.0*prt_k/(prt_k_max-1)*(n-1) + 0.5/*rounding*/;
      printf("--------"); 
    } 
    printf("\n"); 
    for (prt_i=0; prt_i<prt_i_max; prt_i++)
    { i=1.0*prt_i/(prt_i_max-1)*(m-1) + 0.5/*rounding*/;
      printf("%6i |",i); 
      for (prt_k=0; prt_k<prt_k_max; prt_k++)
      { k=1.0*prt_k/(prt_k_max-1)*(n-1) + 0.5/*rounding*/;
        printf("  %6.4f",phi[idx(i,k)]);
      }
      printf("\n");
    }

   } 
   fflush(stdout); upc_barrier; 
  }
 } 
}

void heatpr_masteronly()
{
  int i_global, k_global, ip, kp; 
  int i,k, prt_i,prt_k, prt_i_max, prt_k_max;
  
  /* Each process handles only local i=1..m-2, k=1..n-2.
     Boundary conditions are at i=0, k=0, i=m-1, k=n-1 
     on first and last processes. The total range
     is therefore i_global=0..mprocs*(m-2)+1 
     and k_global=0..nprocs*(n-2)+1. */
 
  fflush(stdout); upc_barrier; 
  if(MYTHREAD == 0) { 
    prt_i_max = min(prtrows, mprocs*(m-2)+2); 
    prt_k_max = min(prtcols, nprocs*(n-2)+2); 
    printf("i  \\  k="); 
    for (prt_k=0; prt_k<prt_k_max; prt_k++)
    { k_global=1.0*prt_k/(prt_k_max-1)*(nprocs*(n-2)+1) + 0.5/*rounding*/;
      printf("  %6i",k_global); 
    } 
    printf("\n"); 
    printf("-------+"); 
    for (prt_k=0; prt_k<prt_k_max; prt_k++)
    { k_global=1.0*prt_k/(prt_k_max-1)*(nprocs*(n-2)+1) + 0.5/*rounding*/;
      printf("--------"); 
    } 
    printf("\n"); 
    for (prt_i=0; prt_i<prt_i_max; prt_i++)
    { i_global=1.0*prt_i/(prt_i_max-1)*(mprocs*(m-2)+1) + 0.5/*rounding*/;
      if (i_global == 0)  { ip=0; i=0; }
      else if (i_global == mprocs*(m-2)+1)  { ip=mprocs-1; i=m-1; }
      else { ip = (i_global-1)/(m-2); i = (i_global-1)%(m-2)+1; } 
      printf("%6i |",i_global); 
      for (prt_k=0; prt_k<prt_k_max; prt_k++)
      { k_global=1.0*prt_k/(prt_k_max-1)*(nprocs*(n-2)+1) + 0.5/*rounding*/;
        if (k_global == 0)  { kp=0; k=0; }
        else if (k_global == nprocs*(n-2)+1)  { kp=nprocs-1; k=n-1; }
        else { kp = (k_global-1)/(n-2); k = (k_global-1)%(n-2)+1; } 
        printf("  %6.4f",xphi[rank(ip,kp)][idx(i,k)]);
      }
      printf("\n");
    }
  } 
  fflush(stdout); upc_barrier; 
}

void heatpr()
{
  /* heatpr_each_process(); */
  heatpr_masteronly();  
}
 
/*--------------------------------------------------------------------------*/ 
 
void halo_exchange_loop()
{
  int i,k;             
  /* exchange:          halo            = real data of neighbor:            */  
  upc_barrier; 
  if (iproc>0) {
    for (k=1;k<n-1;k++) phi[idx(0,k)]   = phi_neighbor_coord0_prev[idx(m-2,k)];
  }
  if (iproc<mprocs-1) {
    for (k=1;k<n-1;k++) phi[idx(m-1,k)] = phi_neighbor_coord0_next[idx(1,k)];
  }
  if (kproc>0) {
    for (i=1;i<m-1;i++) phi[idx(i,0)]   = phi_neighbor_coord1_prev[idx(i,n-2)];
  }
  if (kproc<nprocs-1) {
    for (i=1;i<m-1;i++) phi[idx(i,n-1)] = phi_neighbor_coord1_next[idx(i,1)];
  }
  upc_barrier; 
}
 
void halo_exchange_intrinsic()
{
  int i,k;             

  /* copy non-contiguous date (k=1) and (k=n-2) into local scratch arrays
     that have shared visibility */ 
  /* phivec_coord1first[i=0:m-3] = phi[i=1:m-2][k=1] */
  if (kproc>0) {
    for (i=0;i<m-2;i++) phivec_coord1first[i]  = phi[idx(i+1,1)];
  } 
  /* phivec_coord1last [i=0:m-3] = phi[i=1:m-2][k=n-2] */
  if (kproc<nprocs-1) {
    for (i=0;i<m-2;i++) phivec_coord1last [i]  = phi[idx(i+1,n-2)];
  } 
   
  /* exchange:          halo            = real data of neighbor:            */  
  upc_barrier; 
  if (iproc>0) {
    /* for (k=1;k<n-1;k++) phi[idx(0,k)]   = phi_neighbor_coord0_prev[idx(m-2,k)]; */
    upc_memget(&phi[idx(0,1)], &phi_neighbor_coord0_prev[idx(m-2,1)], (n-2)*sizeof(double)); 
  }
  if (iproc<mprocs-1) {
    /* for (k=1;k<n-1;k++) phi[idx(m-1,k)] = phi_neighbor_coord0_next[idx(1,k)]; */
    upc_memget(&phi[idx(m-1,1)], &phi_neighbor_coord0_next[idx(1,1)], (n-2)*sizeof(double)); 
  }
  if (kproc>0) {
    /* for (i=1;i<m-1;i++) phi[idx(i,0)]   = phi_neighbor_coord1_prev[idx(i,n-2)]; */
    upc_memget(halovec_coord1first, phivec_neighbor_coord1_prev, (m-2)*sizeof(double));
    for (i=1;i<m-1;i++) phi[idx(i,0)] = halovec_coord1first[i-1]; 
  }
  if (kproc<nprocs-1) {
    /* for (i=1;i<m-1;i++) phi[idx(i,n-1)] = phi_neighbor_coord1_next[idx(i,1)]; */
    upc_memget(halovec_coord1last, phivec_neighbor_coord1_next, (m-2)*sizeof(double));
    for (i=1;i<m-1;i++) phi[idx(i,n-1)] = halovec_coord1last[i-1]; 
  }
  upc_barrier; 
}
 
void halo_exchange()
{
  /* halo_exchange_loop(); */
  halo_exchange_intrinsic();
} 

#include <upc_relaxed.h>
#include <stdio.h>

int main(int argc, char** argv)
{
  if (MYTHREAD == 0) printf("hello world\n"); 
  printf("I am thread number %d of %d threads\n", MYTHREAD, THREADS);
  return 0;
}

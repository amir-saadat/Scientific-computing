#include <stdio.h>
#include <time.h>
#include <sys/time.h>

const int n = 100000000;

const double pi_ref = 3.1415926535897932384626433;

int main(int argc, char** argv)
{
  int i;
  double w,x,sum,pi;
  clock_t t1,t2;
  struct timeval tv1,tv2; struct timezone tz;

  gettimeofday(&tv1, &tz);
  t1=clock();
 
/* calculate pi = integral [0..1] 4/(1+x**2) dx */
  w=1.0/n;
  sum=0.0;
  for (i=1;i<=n;i++)
  {
    x=w*((double)i-0.5);
    sum=sum+4.0/(1.0+x*x);
  }
  pi=w*sum;

  t2=clock();
  gettimeofday(&tv2, &tz);
    printf( "computed  pi     = %19.16f\n", pi );
    printf( "reference pi_ref = %19.16f\n", pi_ref );
    printf( "error= pi-pi_ref = %19.16f\n", pi - pi_ref );
    printf( "CPU time (clock)                = %12.6f sec\n", (t2-t1)/1000000.0 );
    printf( "wall clock time (gettimeofday)  = %12.6f sec\n", (tv2.tv_sec-tv1.tv_sec) + (tv2.tv_usec-tv1.tv_usec)*1e-6 );
  return 0;
}
